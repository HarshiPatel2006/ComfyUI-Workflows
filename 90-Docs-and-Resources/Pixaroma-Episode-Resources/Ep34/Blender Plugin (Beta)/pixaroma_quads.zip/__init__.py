bl_info = {
    'name': 'Quads Pixaroma', 'author': 'Pixaroma Studio',
    'version': (2, 0, 0), 'blender': (4, 2, 0),
    'location': 'View3D > Sidebar > Quads Pixaroma',
    'description': 'Repair surfaces, close holes and create quad geometry',
    'category': 'Mesh',
}
import bpy
from . import ui_panel, branding, jobs

class PixaromaQuadsSettings(bpy.types.PropertyGroup):
    quad_method: bpy.props.EnumProperty(name='Topology', items=[
        ('GRID', 'Detail grid', 'Dense, mostly quad surface reconstruction; prioritizes detail over a low face count'),
        ('FLOW', 'Flow quads', 'Lower face-count field-aligned topology; inspect thin parts and fine grooves')], default='GRID')
    repair_method: bpy.props.EnumProperty(name='Surface method', items=[
        ('PRESERVE', 'Preserve surface', 'Repair small holes while retaining existing detail and UVs'),
        ('REBUILD', 'Rebuild surface', 'Voxel reconstruction for damaged scans; can merge nearby parts and lose UVs')], default='PRESERVE')
    target_faces: bpy.props.IntProperty(name='Target faces', default=20000, min=100, max=100000)
    preserve_sharp: bpy.props.BoolProperty(name='Preserve sharp edges', default=False,
        description='Constrain sharp features; can be much slower on noisy scans')
    symmetry: bpy.props.EnumProperty(name='Symmetry', items=[(a, a.title(), 'Object axes; origin must be centered') for a in ('NONE', 'X', 'Y', 'Z')], default='NONE')
    project_details: bpy.props.BoolProperty(name='Project surface detail', default=False,
        description='Limited nearest-surface projection; may distort thin or nearby surfaces')
    projection_limit: bpy.props.FloatProperty(name='Projection range (voxels)', default=1.0, min=0.1, max=3)
    voxel_resolution: bpy.props.IntProperty(name='Surface resolution', default=256, min=64, max=384,
        description='Voxels across longest dimension; higher retains smaller features and uses more memory')
    weld_ratio: bpy.props.FloatProperty(name='Weld distance / size', default=0.00001, min=0.0000001, max=0.001, precision=7,
        description='Merge distance as a fraction of longest dimension; 0.00001 = 0.001 percent')
    hole_ratio: bpy.props.FloatProperty(name='Max hole size (%)', default=10, min=0.1, max=100, precision=1,
        description='Hole extent as percent of model size; 100 fills all simple boundary loops')
    smooth_shading: bpy.props.BoolProperty(name='Smooth shading', default=True,
        description='Smooth shading with sharp normal breaks at 35 degrees; does not change geometry')
    max_angle: bpy.props.FloatProperty(name='Join angle', default=40.0, min=1, max=90)
    last_result: bpy.props.StringProperty(default='')

classes = (PixaromaQuadsSettings,) + ui_panel.CLASSES

def register():
    branding.register()
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.pixaroma_quads_settings = bpy.props.PointerProperty(type=PixaromaQuadsSettings)
    bpy.app.handlers.load_pre.append(jobs.shutdown)

def unregister():
    jobs.shutdown()
    if jobs.shutdown in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.remove(jobs.shutdown)
    del bpy.types.Scene.pixaroma_quads_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    branding.unregister()
