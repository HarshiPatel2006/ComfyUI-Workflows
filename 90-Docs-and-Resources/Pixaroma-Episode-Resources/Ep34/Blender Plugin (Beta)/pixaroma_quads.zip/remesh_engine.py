"""Transactional repair/remesh: commit a result copy only after validation."""
import math
import json
import bpy
import bmesh
from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree
from . import geometry

def activate(context, obj):
    for other in context.selected_objects:
        other.select_set(False)
    obj.hide_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj

def normalize(obj):
    world = obj.matrix_world.copy()
    if abs(world.determinant()) < 1e-30:
        raise ValueError('Object has a zero scale. Set a nonzero scale first.')
    # Keep object axes for symmetry, bake scale but not rotation.
    scale = Vector(tuple(world.to_scale()))
    if world.determinant() < 0:
        scale.x = -scale.x
    bake = Matrix.Diagonal((*scale, 1.0))
    obj.data.transform(bake)
    size = geometry.extent(obj.data.vertices)
    if size < 1e-12:
        raise ValueError('Mesh has no usable surface size.')
    transform = Matrix.Scale(10.0 / size, 4)
    obj.data.transform(transform)
    obj.matrix_world = Matrix.Identity(4)
    return bake.inverted() @ transform.inverted(), world

def surface_tree(mesh):
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        return BVHTree.FromBMesh(bm)
    finally:
        bm.free()

def bounded_projection(obj, tree, limit):
    saved = [v.co.copy() for v in obj.data.vertices]
    normals = [p.normal.copy() for p in obj.data.polygons]
    for vertex in obj.data.vertices:
        hit, normal, index, distance = tree.find_nearest(vertex.co)
        if hit is not None and distance <= limit:
            vertex.co = hit
    obj.data.update()
    invalid = any(p.area < 1e-12 or p.normal.dot(n) < 0.1
                  for p, n in zip(obj.data.polygons, normals))
    if invalid:
        for vertex, co in zip(obj.data.vertices, saved):
            vertex.co = co
        obj.data.update()
    return not invalid

def voxel_rebuild(obj, resolution):
    obj.data.remesh_voxel_size = 10.0 / resolution
    obj.data.remesh_voxel_adaptivity = 0.0
    obj.data.use_remesh_preserve_volume = True
    result = bpy.ops.object.voxel_remesh()
    if 'FINISHED' not in result or not obj.data.polygons:
        raise RuntimeError('Surface rebuild produced no usable surface. Try a finer resolution.')
    geometry.clean_mesh(obj, weld_ratio=0.000001, hole_ratio=1.01)
    geometry.split_vertex_fans(obj)

def _quadriflow_once(obj, settings, seed=0, multiplier=1):
    before = geometry.get_mesh_stats(obj)
    if before['non_manifold_edges'] or before['inconsistent_edges']:
        raise ValueError('Mesh has non-manifold junctions. Use Rebuild surface first.')
    obj.data.use_mirror_x = settings.symmetry == 'X'
    obj.data.use_mirror_y = settings.symmetry == 'Y'
    obj.data.use_mirror_z = settings.symmetry == 'Z'
    old_pointer = obj.data.as_pointer()
    old_counts = (len(obj.data.vertices), len(obj.data.polygons))
    # Blender's native preflight treats component-wise edge differences below
    # 1e-4 as zero length. A fixed model-size normalization is insufficient for
    # dense voxel meshes; scale to their smallest actual edge for this solve.
    coords = [v.co.copy() for v in obj.data.vertices]
    minimum = min(max(abs(a-b) for a, b in zip(coords[e.vertices[0]], coords[e.vertices[1]])) for e in obj.data.edges)
    if minimum <= 1e-12:
        raise ValueError('Coincident connected vertices remain. Rebuild the surface first.')
    solver_scale = max(1.0, 0.00025 / minimum)
    obj.data.transform(Matrix.Scale(solver_scale, 4))
    try:
        result = bpy.ops.object.quadriflow_remesh(
            mode='FACES', target_faces=int(settings.target_faces * multiplier),
            use_preserve_sharp=settings.preserve_sharp,
            use_preserve_boundary=True,
            use_mesh_symmetry=settings.symmetry != 'NONE', seed=seed)
    finally:
        obj.data.transform(Matrix.Scale(1.0 / solver_scale, 4))
    if 'FINISHED' not in result:
        raise RuntimeError('QuadriFlow cancelled. Try Rebuild surface or a higher target.')
    geometry.clean_mesh(obj, weld_ratio=0.0000001, hole_ratio=1.01)
    stats = geometry.get_mesh_stats(obj)
    print('QUADS_DIAGNOSTICS', stats, flush=True)
    unchanged = obj.data.as_pointer() == old_pointer and old_counts == (len(obj.data.vertices), len(obj.data.polygons))
    if not stats['faces'] or stats['quads_pct'] < 95 or unchanged:
        raise RuntimeError('QuadriFlow did not produce a new quad mesh. Try Rebuild surface.')
    if stats['non_manifold_edges'] or stats['degenerate_faces']:
        raise RuntimeError('Quad result failed topology checks. Increase the target or rebuild resolution.')
    if not before['boundary_edges'] and stats['boundary_edges']:
        raise RuntimeError('Quad solver introduced open edges.')

def quadriflow(obj, settings):
    snapshot = obj.data.copy()
    errors = []
    try:
        for seed, multiplier in ((0, 1), (19, 1.5), (73, 2)):
            if errors:
                failed = obj.data
                obj.data = snapshot.copy()
                if failed.users == 0:
                    bpy.data.meshes.remove(failed)
                print('Quads Pixaroma: retrying with a denser quad layout', flush=True)
            try:
                _quadriflow_once(obj, settings, seed, multiplier)
                return
            except (RuntimeError, ValueError) as exc:
                errors.append(str(exc))
        # A closed voxel shell is itself a quad mesh. If field alignment fails,
        # keep that valid dense grid, and explicitly disclose the missed target.
        if settings.repair_method == 'REBUILD':
            failed = obj.data
            obj.data = snapshot.copy()
            if failed.users == 0:
                bpy.data.meshes.remove(failed)
            stats = geometry.get_mesh_stats(obj)
            if not stats['boundary_edges'] and not stats['non_manifold_edges'] and not stats['degenerate_faces'] and stats['quads_pct'] >= 95:
                obj['quads_pixaroma_note'] = 'Dense grid fallback: target face count not reached.'
                return
        raise RuntimeError(errors[-1] + ' Try a finer surface resolution.')
    finally:
        bpy.data.meshes.remove(snapshot)

def run(context, source, settings, action):
    if source.mode != 'OBJECT':
        raise ValueError('Switch to Object Mode before processing.')
    if not source.data.polygons:
        raise ValueError('Select a mesh with faces.')
    if source.data.shape_keys:
        raise ValueError('Mesh has shape keys. Apply them to a separate copy first.')
    if source.modifiers:
        raise ValueError('Apply modifiers on a separate copy before processing.')
    selected = list(context.selected_objects)
    source_hidden = source.hide_get()
    work = source.copy()
    work.data = source.data.copy()
    if 'quads_pixaroma_note' in work:
        del work['quads_pixaroma_note']
    context.collection.objects.link(work)
    owned_meshes = [work.data]
    succeeded = False
    try:
        activate(context, work)
        restore, world = normalize(work)
        tree = surface_tree(work.data) if settings.project_details and action == 'QUADS' else None
        print('Quads Pixaroma: cleaning surface', flush=True)
        hole_ratio = 1.01 if settings.hole_ratio == 100 else settings.hole_ratio / 100
        fill_report = geometry.clean_mesh(work, settings.weld_ratio, hole_ratio, fill=action != 'JOIN')
        rebuilt = (settings.repair_method == 'REBUILD' and action in {'REPAIR', 'QUADS'}) or (action == 'QUADS' and settings.quad_method == 'GRID')
        if rebuilt:
            print('Quads Pixaroma: rebuilding surface', flush=True)
            voxel_rebuild(work, settings.voxel_resolution)
            owned_meshes.append(work.data)
        if action == 'QUADS' and settings.quad_method == 'FLOW':
            print('Quads Pixaroma: solving quads', flush=True)
            quadriflow(work, settings)
        elif action == 'JOIN':
            bm = bmesh.new()
            try:
                bm.from_mesh(work.data)
                bmesh.ops.join_triangles(bm, faces=list(bm.faces),
                    angle_face_threshold=math.radians(settings.max_angle),
                    angle_shape_threshold=math.radians(settings.max_angle),
                    cmp_seam=True, cmp_sharp=True, cmp_uvs=True, cmp_vcols=True, cmp_materials=True)
                bm.to_mesh(work.data)
            finally:
                bm.free()
        if tree:
            fill_report['projection_applied'] = bounded_projection(work, tree,
                10.0 / settings.voxel_resolution * settings.projection_limit)
        stats = geometry.get_mesh_stats(work)
        if not stats['faces']:
            raise RuntimeError('Operation removed all faces; original preserved.')
        if rebuilt and (stats['boundary_edges'] or stats['non_manifold_edges']):
            raise RuntimeError('Rebuild left open/non-manifold edges. Increase surface resolution.')
        work.data.transform(restore)
        work.matrix_world = world
        work.data.update()
        if settings.smooth_shading:
            for polygon in work.data.polygons:
                polygon.use_smooth = True
            work.data.set_sharp_from_angle(angle=math.radians(35))
        context.view_layer.update()
        work.name = source.name + ('_Quads' if action in {'QUADS', 'JOIN'} else '_Clean')
        work['quads_pixaroma_stats'] = json.dumps(stats)
        work['quads_pixaroma_source'] = source.name
        fill_report['note'] = work.get('quads_pixaroma_note', '')
        work.hide_render = source.hide_render
        source.hide_set(True)
        source.hide_render = True
        succeeded = True
        return work, stats, fill_report, rebuilt
    finally:
        if not succeeded:
            owned_meshes.append(work.data)
            bpy.data.objects.remove(work, do_unlink=True)
            source.hide_set(source_hidden)
            for item in selected:
                item.select_set(True)
            context.view_layer.objects.active = source
        for mesh in set(owned_meshes):
            try:
                if mesh.users == 0:
                    bpy.data.meshes.remove(mesh)
            except ReferenceError:
                pass
