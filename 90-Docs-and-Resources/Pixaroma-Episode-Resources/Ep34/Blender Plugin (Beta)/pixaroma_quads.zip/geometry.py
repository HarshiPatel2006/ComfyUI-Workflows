"""Measured diagnostics and conservative, size-relative surface repair."""
import bmesh

def quad_percent(stats):
    return '100%' if stats['faces'] and stats['quads'] == stats['faces'] else f"{min(99.999, stats['quads_pct']):.3f}%"

def boundary_groups(bm):
    remaining = {e for e in bm.edges if e.is_boundary}
    groups = []
    while remaining:
        edge = remaining.pop()
        group, pending = [edge], [edge]
        while pending:
            for vertex in pending.pop().verts:
                for neighbor in vertex.link_edges:
                    if neighbor in remaining:
                        remaining.remove(neighbor)
                        group.append(neighbor)
                        pending.append(neighbor)
        groups.append(group)
    return groups

def is_loop(edges):
    degrees = {}
    for edge in edges:
        for vert in edge.verts:
            degrees[vert] = degrees.get(vert, 0) + 1
    return len(edges) >= 3 and all(n == 2 for n in degrees.values())

def extent(verts):
    coords = [v.co for v in verts]
    return max(max(v[i] for v in coords) - min(v[i] for v in coords)
               for i in range(3)) if coords else 0.0

def get_mesh_stats(obj):
    bm = bmesh.new()
    try:
        bm.from_mesh(obj.data)
        groups = boundary_groups(bm)
        counts = {n: sum(len(f.verts) == n for f in bm.faces) for n in (3, 4)}
        faces = len(bm.faces)
        size = extent(bm.verts)
        return dict(vertices=len(bm.verts), faces=faces, quads=counts[4],
            quads_pct=100 * counts[4] / max(1, faces),
            triangles=counts[3], ngons=faces-counts[3]-counts[4],
            boundary_edges=sum(e.is_boundary for e in bm.edges),
            holes=sum(is_loop(g) for g in groups),
            branched_boundaries=sum(not is_loop(g) for g in groups),
            non_manifold_edges=sum(len(e.link_faces) > 2 for e in bm.edges),
            loose_edges=sum(not e.link_faces for e in bm.edges),
            loose_vertices=sum(not v.link_edges for v in bm.verts),
            degenerate_faces=sum(f.calc_area() <= max(size**2 * 1e-16, 1e-30) for f in bm.faces),
            inconsistent_edges=sum(e.is_manifold and not e.is_contiguous for e in bm.edges))
    finally:
        bm.free()

def split_vertex_fans(obj):
    """Separate closed shells touching at a single vertex after voxel rebuild.

    QuadriFlow rejects these bow-ties although every edge has two faces.
    Called only on reconstructed surfaces, whose original UVs are already lost.
    """
    bm = bmesh.new()
    try:
        bm.from_mesh(obj.data)
        bm.verts.index_update()
        bm.faces.index_update()
        coords = [tuple(v.co) for v in bm.verts]
        faces = [[v.index for v in f.verts] for f in bm.faces]
        materials = [f.material_index for f in bm.faces]
        splits = 0
        for vertex in bm.verts:
            if vertex.is_manifold or not vertex.link_faces:
                continue
            remaining = set(vertex.link_faces)
            fans = []
            while remaining:
                face = remaining.pop()
                fan, pending = [face], [face]
                while pending:
                    for edge in pending.pop().edges:
                        if vertex not in edge.verts:
                            continue
                        for neighbor in edge.link_faces:
                            if neighbor in remaining:
                                remaining.remove(neighbor)
                                fan.append(neighbor)
                                pending.append(neighbor)
                fans.append(fan)
            for fan in fans[1:]:
                index = len(coords)
                coords.append(tuple(vertex.co))
                for face in fan:
                    faces[face.index] = [index if i == vertex.index else i for i in faces[face.index]]
                splits += 1
        if splits:
            obj.data.clear_geometry()
            obj.data.from_pydata(coords, [], faces)
            for polygon, material in zip(obj.data.polygons, materials):
                polygon.material_index = material
            obj.data.update()
        return splits
    finally:
        bm.free()

def clean_mesh(obj, weld_ratio=0.00001, hole_ratio=0.1, fill=True):
    """Cap separate simple loops only. hole_ratio is extent / model size."""
    bm = bmesh.new()
    try:
        bm.from_mesh(obj.data)
        size = extent(bm.verts)
        tolerance = max(size * weld_ratio, 1e-12)
        # Coincident shells can become non-manifold when welded. Reject such a
        # weld rather than making a previously manifold surface worse.
        previous = bm.copy()
        junctions = sum(len(e.link_faces) > 2 for e in bm.edges)
        boundary = [v for v in bm.verts if any(e.is_boundary for e in v.link_edges)]
        targets = bmesh.ops.find_doubles(bm, verts=boundary, dist=tolerance)['targetmap'] if boundary else {}
        if targets:
            # Reject only unsafe seam merges, rather than throwing away all
            # useful welding because one overlapping shell is problematic.
            bm.verts.index_update()
            counts = {}
            for edge in bm.edges:
                a, b = (targets.get(v, v).index for v in edge.verts)
                if a == b:
                    continue
                key = (min(a, b), max(a, b))
                counts[key] = counts.get(key, 0) + len(edge.link_faces)
            unsafe = {index for pair, count in counts.items() if count > 2 for index in pair}
            targets = {v: target for v, target in targets.items() if target.index not in unsafe}
            bmesh.ops.weld_verts(bm, targetmap=targets)
        if sum(len(e.link_faces) > 2 for e in bm.edges) > junctions:
            bm.free()
            bm = previous
        else:
            previous.free()
        bmesh.ops.dissolve_degenerate(bm, edges=list(bm.edges), dist=tolerance)
        zero_faces = [f for f in bm.faces if f.calc_area() <= max(size**2 * 1e-16, 1e-30)]
        if zero_faces:
            bmesh.ops.delete(bm, geom=zero_faces, context='FACES_ONLY')
        seen, duplicates = set(), []
        for face in bm.faces:
            key = frozenset(face.verts)
            if key in seen:
                duplicates.append(face)
            seen.add(key)
        if duplicates:
            bmesh.ops.delete(bm, geom=duplicates, context='FACES_ONLY')
        loose_edges = [e for e in bm.edges if not e.link_faces]
        if loose_edges:
            bmesh.ops.delete(bm, geom=loose_edges, context='EDGES')
        loose = [v for v in bm.verts if not v.link_faces]
        if loose:
            bmesh.ops.delete(bm, geom=loose, context='VERTS')
        filled, skipped = 0, 0
        if fill:
            eligible = []
            for edges in boundary_groups(bm):
                vertices = {v for e in edges for v in e.verts}
                if not is_loop(edges) or extent(vertices) > size * hole_ratio:
                    skipped += 1
                    continue
                eligible.append(edges)
            # One BMesh operation for all disconnected loops avoids repeated
            # full-mesh scans on million-face imports with thousands of holes.
            if eligible:
                cap = bmesh.ops.holes_fill(bm, edges=[e for group in eligible for e in group], sides=0)['faces']
                cap_set = set(cap)
                for face in cap:
                    adjacent = next((f for e in face.edges for f in e.link_faces if f not in cap_set), None)
                    if adjacent:
                        face.material_index, face.smooth = adjacent.material_index, adjacent.smooth
                if cap:
                    triangles = set(bmesh.ops.triangulate(bm, faces=cap, quad_method='BEAUTY', ngon_method='BEAUTY')['faces'])
                    # Slit-shaped or overlapping loops can tessellate into
                    # zero-area faces or reuse an existing interior edge.
                    # Reject the connected new patch rather than damage it.
                    unsafe = {f for f in triangles if f.calc_area() <= max(size**2 * 1e-16, 1e-30)
                              or any(len(e.link_faces) > 2 for e in f.edges)}
                    pending = list(unsafe)
                    while pending:
                        for edge in pending.pop().edges:
                            for face in edge.link_faces:
                                if face in triangles and face not in unsafe:
                                    unsafe.add(face)
                                    pending.append(face)
                    if unsafe:
                        bmesh.ops.delete(bm, geom=list(unsafe), context='FACES_ONLY')
                    wires = [e for e in bm.edges if not e.link_faces]
                    if wires:
                        bmesh.ops.delete(bm, geom=wires, context='EDGES')
                filled = sum(not any(e.is_valid and e.is_boundary for e in group) for group in eligible)
                skipped += len(eligible) - filled
        bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
        bm.to_mesh(obj.data)
        obj.data.update()
        return dict(filled=filled, skipped=skipped)
    finally:
        bm.free()
