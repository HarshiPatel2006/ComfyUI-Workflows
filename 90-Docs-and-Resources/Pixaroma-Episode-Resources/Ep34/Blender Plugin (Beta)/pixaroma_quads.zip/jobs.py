"""Keep Blender responsive while the native remesher runs in a child process."""
import bpy
import json
import os
import subprocess
import tempfile
import shutil
from pathlib import Path
from . import geometry

active = False
active_operator = None
SETTING_NAMES = ('repair_method', 'quad_method', 'target_faces', 'preserve_sharp', 'symmetry',
                 'project_details', 'projection_limit', 'voxel_resolution',
                 'weld_ratio', 'hole_ratio', 'max_angle', 'smooth_shading')

def start(operator, context):
    global active, active_operator
    source = context.active_object
    if active:
        raise RuntimeError('A Quads Pixaroma operation is already running.')
    if source.modifiers or source.data.shape_keys or source.constraints or source.animation_data:
        raise ValueError('Apply modifiers, shape keys and animation on a separate copy first.')
    operator._source = source
    operator._folder = Path(tempfile.mkdtemp(prefix='quads_pixaroma_'))
    folder = operator._folder
    settings = context.scene.pixaroma_quads_settings
    bpy.data.libraries.write(str(folder / 'input.blend'), {source})
    (folder / 'request.json').write_text(json.dumps(dict(object=source.name,
        action=operator.action, settings={key: getattr(settings, key) for key in SETTING_NAMES})))
    operator._log = (folder / 'worker.log').open('w')
    env = os.environ.copy()
    env['OMP_NUM_THREADS'] = str(max(1, min(8, (os.cpu_count() or 4)//2)))
    operator._process = subprocess.Popen([bpy.app.binary_path, '--background', '--factory-startup',
        '--threads', env['OMP_NUM_THREADS'], '--python-exit-code', '1', '--python',
        str(Path(__file__).with_name('worker.py')), '--', str(folder)],
        stdout=operator._log, stderr=subprocess.STDOUT, env=env,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    operator._timer = context.window_manager.event_timer_add(0.3, window=context.window)
    context.window_manager.modal_handler_add(operator)
    active = True
    active_operator = operator
    settings.last_result = 'Working in background — Esc cancels.'

def cleanup(operator, context):
    global active, active_operator
    process = getattr(operator, '_process', None)
    if process is not None and process.poll() is None:
        process.kill()
        process.wait(timeout=10)
    if getattr(operator, '_timer', None):
        context.window_manager.event_timer_remove(operator._timer)
    if getattr(operator, '_log', None):
        operator._log.close()
    if getattr(operator, '_folder', None):
        shutil.rmtree(operator._folder, ignore_errors=True)
    active = False
    active_operator = None

@bpy.app.handlers.persistent
def shutdown(*args):
    if active_operator is not None:
        cleanup(active_operator, bpy.context)

def modal(operator, context, event):
    settings = context.scene.pixaroma_quads_settings
    if event.type == 'ESC':
        operator._process.kill()
        operator._process.wait(timeout=10)
        cleanup(operator, context)
        settings.last_result = 'Cancelled. Original preserved.'
        return {'CANCELLED'}
    if event.type != 'TIMER':
        return {'PASS_THROUGH'}
    if operator._process.poll() is None:
        log = (operator._folder / 'worker.log').read_text(errors='replace')
        stages = [line for line in log.splitlines() if line.startswith('Quads Pixaroma:')]
        if stages:
            settings.last_result = stages[-1].replace('Quads Pixaroma: ', '').capitalize() + ' — Esc cancels'
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        return {'PASS_THROUGH'}
    try:
        folder = operator._folder
        if not (folder / 'result.json').exists():
            error = (folder / 'error.txt').read_text().splitlines()[0] if (folder / 'error.txt').exists() else 'Worker stopped unexpectedly. Original preserved.'
            raise RuntimeError(error)
        info = json.loads((folder / 'result.json').read_text())
        source = operator._source
        if source.name not in context.scene.objects:
            raise RuntimeError('Source was removed while processing; result not applied.')
        if context.object and context.object.mode != 'OBJECT':
            raise RuntimeError('Return to Object Mode before applying a result. Original preserved.')
        with bpy.data.libraries.load(str(folder / 'output.blend'), link=False) as (available, data):
            data.objects = [info['object']]
        output = data.objects[0]
        context.collection.objects.link(output)
        output.hide_set(False)
        output.hide_render = source.hide_render
        source.hide_set(True)
        source.hide_render = True
        for obj in context.selected_objects:
            obj.select_set(False)
        output.select_set(True)
        context.view_layer.objects.active = output
        stats = info['stats']
        settings.last_result = f"{stats['faces']:,} faces; {geometry.quad_percent(stats)} quads"
        issues = stats['boundary_edges'] or stats['non_manifold_edges'] or stats['degenerate_faces']
        operator.report({'WARNING'} if issues else {'INFO'}, settings.last_result + ('. Open or non-manifold edges remain; inspect Analyze.' if issues else ''))
        return {'FINISHED'}
    except Exception as exc:
        settings.last_result = str(exc)
        operator.report({'ERROR'}, str(exc))
        return {'CANCELLED'}
    finally:
        cleanup(operator, context)
