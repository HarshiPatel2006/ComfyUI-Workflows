"""Background Blender worker; input and output remain in a temporary directory."""
import bpy
import sys
import json
import importlib.util
import traceback
from pathlib import Path

folder = Path(sys.argv[sys.argv.index('--') + 1])
try:
    config = json.loads((folder / 'request.json').read_text())
    package = Path(__file__).parent
    spec = importlib.util.spec_from_file_location('qp_worker_addon', package / '__init__.py',
                                               submodule_search_locations=[str(package)])
    addon = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = addon
    spec.loader.exec_module(addon)
    addon.register()
    with bpy.data.libraries.load(str(folder / 'input.blend'), link=False) as (available, data):
        data.objects = [config['object']]
    source = data.objects[0]
    bpy.context.scene.collection.objects.link(source)
    matrix = source.matrix_world.copy()
    source.parent = None
    source.matrix_world = matrix
    settings = bpy.context.scene.pixaroma_quads_settings
    for key, value in config['settings'].items():
        setattr(settings, key, value)
    output, stats, repair, rebuilt = addon.remesh_engine.run(bpy.context, source, settings, config['action'])
    bpy.data.libraries.write(str(folder / 'output.blend'), {output})
    (folder / 'result.json').write_text(json.dumps(dict(object=output.name, stats=stats, repair=repair)))
except Exception as exc:
    (folder / 'error.txt').write_text(str(exc) + '\n' + traceback.format_exc())
    raise
