import json
import bpy
from . import geometry, remesh_engine, branding, jobs

class MeshOperator:
    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH' and context.active_object.mode == 'OBJECT'

class OBJECT_OT_qp_analyze(MeshOperator, bpy.types.Operator):
    bl_idname = 'object.qp_analyze'
    bl_label = 'Analyze Mesh'
    bl_description = 'Refresh topology counts; analysis is a snapshot, not a live scan'
    def execute(self, context):
        obj = context.active_object
        obj['quads_pixaroma_stats'] = json.dumps(geometry.get_mesh_stats(obj))
        return {'FINISHED'}

class OBJECT_OT_qp_process(MeshOperator, bpy.types.Operator):
    @classmethod
    def poll(cls, context):
        return MeshOperator.poll(context) and not jobs.active
    bl_idname = 'object.qp_process'
    bl_label = 'Quads Pixaroma'
    bl_description = 'Create a processed copy and hide the original; undo restores previous state'
    bl_options = {'REGISTER', 'UNDO'}
    action: bpy.props.EnumProperty(items=[('REPAIR', 'Repair', ''), ('QUADS', 'Quads', ''), ('JOIN', 'Join triangles', '')])
    def invoke(self, context, event):
        try:
            jobs.start(self, context)
            return {'RUNNING_MODAL'}
        except Exception as exc:
            jobs.cleanup(self, context)
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
    def modal(self, context, event):
        return jobs.modal(self, context, event)
    def execute(self, context):
        settings = context.scene.pixaroma_quads_settings
        context.window_manager.progress_begin(0, 3)
        try:
            obj, stats, repair, rebuilt = remesh_engine.run(context, context.active_object, settings, self.action)
            message = f"{stats['faces']:,} faces | {geometry.quad_percent(stats)} quads | {stats['holes']} open loops"
            settings.last_result = message
            self.report({'WARNING'} if stats['non_manifold_edges'] else {'INFO'}, message)
            return {'FINISHED'}
        except Exception as exc:
            settings.last_result = str(exc)
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        finally:
            context.window_manager.progress_end()

class OBJECT_OT_qp_boundaries(MeshOperator, bpy.types.Operator):
    bl_idname = 'object.qp_boundaries'
    bl_label = 'Inspect Open Edges'
    bl_description = 'Select boundary and non-manifold edges in Edit Mode'
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_mode(type='EDGE')
        bpy.ops.mesh.select_non_manifold()
        return {'FINISHED'}

class PanelBase:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Quads Pixaroma'

class VIEW3D_PT_qp_main(PanelBase, bpy.types.Panel):
    bl_idname = 'VIEW3D_PT_qp_main'
    bl_label = 'Quads Pixaroma'
    def draw(self, context):
        col = self.layout.column(align=True)
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            col.label(text='Select a mesh to begin.', icon='MESH_DATA')
            return
        col.label(text=obj.name, icon='MESH_DATA')
        col.label(text='Results are created as new objects.')
        if obj.get('quads_pixaroma_note'):
            col.label(text='Dense grid fallback', icon='INFO')
            col.label(text='Target face count was not reached.')
        message = context.scene.pixaroma_quads_settings.last_result
        if message:
            col.label(text=message, icon='INFO')
        if obj.mode != 'OBJECT':
            col.label(text='Return to Object Mode to process.', icon='INFO')

class VIEW3D_PT_qp_analyze(PanelBase, bpy.types.Panel):
    bl_parent_id = 'VIEW3D_PT_qp_main'
    bl_label = 'Analyze'
    def draw_header(self, context):
        self.layout.label(text='', icon_value=branding.icon('step1'))
    def draw(self, context):
        layout = self.layout
        layout.operator('object.qp_analyze', icon='VIEWZOOM')
        obj = context.active_object
        raw = obj.get('quads_pixaroma_stats') if obj else None
        if raw:
            stats = json.loads(raw)
            col = layout.column(align=True)
            col.label(text=f"Faces: {stats['faces']:,}")
            col.label(text=f"Quads: {geometry.quad_percent(stats)}")
            col.label(text=f"Triangles: {stats['triangles']:,}  /  N-gons: {stats['ngons']:,}")
            col.label(text=f"Open loops: {stats['holes']:,}")
            col.label(text=f"Branched boundaries: {stats['branched_boundaries']:,}")
            col.label(text=f"Non-manifold junctions: {stats['non_manifold_edges']:,}")
            col.label(text='Snapshot — refresh after editing.', icon='INFO')
            layout.operator('object.qp_boundaries', icon='EDITMODE_HLT')

class VIEW3D_PT_qp_repair(PanelBase, bpy.types.Panel):
    bl_parent_id = 'VIEW3D_PT_qp_main'
    bl_label = 'Repair'
    def draw_header(self, context):
        self.layout.label(text='', icon_value=branding.icon('step2'))
    def draw(self, context):
        layout = self.layout
        s = context.scene.pixaroma_quads_settings
        layout.prop(s, 'repair_method', text='')
        col = layout.column(align=True)
        if s.repair_method == 'PRESERVE':
            col.label(text='Keep detail; close small openings.')
            col.prop(s, 'hole_ratio')
        else:
            col.label(text='Reconstruct a damaged surface.')
            col.prop(s, 'voxel_resolution')
            col.label(text='May merge parts or remove details.', icon='INFO')
            col.label(text='UVs need rebuilding afterward.')
        row = layout.row()
        row.scale_y = 1.4
        row.operator('object.qp_process', text='Repair Surface', icon_value=branding.icon('repair')).action = 'REPAIR'

class VIEW3D_PT_qp_quads(PanelBase, bpy.types.Panel):
    bl_parent_id = 'VIEW3D_PT_qp_main'
    bl_label = 'Quads'
    def draw_header(self, context):
        self.layout.label(text='', icon_value=branding.icon('step3'))
    def draw(self, context):
        layout = self.layout
        s = context.scene.pixaroma_quads_settings
        layout.prop(s, 'quad_method', text='')
        if s.quad_method == 'GRID':
            layout.label(text='Rebuild with detail-preserving density.')
            layout.prop(s, 'voxel_resolution', text='Detail resolution')
        else:
            layout.label(text='Uses the repair method above.')
            layout.prop(s, 'target_faces')
            layout.prop(s, 'preserve_sharp')
            layout.prop(s, 'symmetry')
            layout.label(text='Check fine grooves and thin parts.')
        row = layout.row()
        row.scale_y = 1.4
        row.operator('object.qp_process', text='Create Quads', icon_value=branding.icon('quads')).action = 'QUADS'
        layout.label(text='New topology needs new UVs.', icon='INFO')

class VIEW3D_PT_qp_advanced(PanelBase, bpy.types.Panel):
    bl_parent_id = 'VIEW3D_PT_qp_main'
    bl_label = 'Advanced'
    bl_options = {'DEFAULT_CLOSED'}
    def draw(self, context):
        layout = self.layout
        s = context.scene.pixaroma_quads_settings
        layout.prop(s, 'weld_ratio')
        layout.prop(s, 'smooth_shading')
        layout.prop(s, 'project_details')
        if s.project_details:
            layout.prop(s, 'projection_limit')
        layout.separator()
        layout.label(text='Pair existing triangles')
        layout.prop(s, 'max_angle')
        layout.operator('object.qp_process', text='Join Triangles', icon='MESH_PLANE').action = 'JOIN'
        layout.label(text='Preserves UV seams; may leave tris.')

CLASSES = (OBJECT_OT_qp_analyze, OBJECT_OT_qp_process, OBJECT_OT_qp_boundaries,
           VIEW3D_PT_qp_main, VIEW3D_PT_qp_analyze, VIEW3D_PT_qp_repair,
           VIEW3D_PT_qp_quads, VIEW3D_PT_qp_advanced)
