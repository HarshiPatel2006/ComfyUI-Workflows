"""Orange/gray native sidebar icons; never modify the user's Blender theme."""
import bpy.utils.previews

ORANGE = (246/255, 103/255, 68/255, 1)
DARK = (29/255, 29/255, 29/255, 1)
BODY = (42/255, 42/255, 42/255, 1)
WHITE = (0.94, 0.94, 0.94, 1)
_previews = None

GLYPHS = {
    'step1': ['00100','01100','00100','00100','00100','00100','01110'],
    'step2': ['01110','10001','00001','00010','00100','01000','11111'],
    'step3': ['11110','00001','00001','01110','00001','00001','11110'],
    'action': ['00100','00100','00100','10101','01110','00100','11111'],
    'quads': ['11111','10101','11111','10101','11111','00000','00000'],
    'repair': ['00100','00100','11111','00100','00100','00000','00000'],
}

def register():
    global _previews
    _previews = bpy.utils.previews.new()
    for name, rows in GLYPHS.items():
        size = 32
        pixels = []
        for y in range(size):
            for x in range(size):
                inside = 2 <= x < 30 and 2 <= y < 30
                color = BODY if inside else (0, 0, 0, 0)
                if inside and (x in (2, 3, 28, 29) or y in (2, 3, 28, 29)):
                    color = ORANGE
                gx, gy = (x-6)//4, (29-y)//4
                if 0 <= gx < 5 and 0 <= gy < 7 and rows[gy][gx] == '1':
                    color = ORANGE if name.startswith('step') else WHITE
                pixels.extend(color)
        preview = _previews.new(name)
        preview.icon_size = (size, size)
        preview.icon_pixels_float = pixels

def icon(name):
    return _previews[name].icon_id if _previews and name in _previews else 0

def unregister():
    global _previews
    if _previews is not None:
        bpy.utils.previews.remove(_previews)
        _previews = None
